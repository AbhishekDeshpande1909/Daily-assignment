#include<iostream>
using namespace std;
int main(){
	int a=11;
	int b=20;
	int temp;
	cout<<"before swapping"<<endl;
		cout<<"a="<<a<<endl;
		cout<<"b="<<b<<endl;
	temp=a;
	a=b;
	b=temp;
	cout<<"after swapping"<<endl;
	cout<<"a="<<a<<endl;
		cout<<"b="<<b<<endl;
	return 0;
}
