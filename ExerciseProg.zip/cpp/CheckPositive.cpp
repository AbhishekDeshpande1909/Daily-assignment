#include<iostream>
using namespace std;
int main()
{
	int n;
	cout<<"enter the number";
	cin>>n;
	if(n>=0)
	{
		cout<<"number is positive";
	}
	else{
		cout<<"number is negative";
	}
return 0;
}
